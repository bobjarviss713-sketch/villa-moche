<?php
/**
 * Facturación Electrónica SUNAT - Endpoint API
 * Villa Moche ERP
 * 
 * Coloque este archivo en la raíz del hosting (misma carpeta que menu/ y admin/)
 * Compatible con Nubefact, Factura.pe, y otros PSE
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Log de operaciones (opcional, para debugging)
function logFacturacion($action, $data, $response) {
    $logFile = __DIR__ . '/facturacion_log.txt';
    $timestamp = date('Y-m-d H:i:s');
    $log = "[$timestamp] $action\n";
    $log .= "Request: " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n";
    $log .= "Response: " . json_encode($response, JSON_UNESCAPED_UNICODE) . "\n";
    $log .= str_repeat('-', 80) . "\n";
    @file_put_contents($logFile, $log, FILE_APPEND);
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$apiKey = $input['apiKey'] ?? '';
$apiUrl = $input['apiUrl'] ?? '';

if (empty($apiKey) || empty($apiUrl)) {
    echo json_encode(['success' => false, 'message' => 'apiKey y apiUrl requeridos']);
    exit;
}

function sendToPSE($apiUrl, $apiKey, $payload) {
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Token token=' . $apiKey,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['code' => 0, 'body' => null, 'error' => $error];
    }
    return ['code' => $httpCode, 'body' => json_decode($response, true), 'error' => null];
}

$response = ['success' => false, 'message' => 'Acción no válida'];

// Probar conexión
if ($action === 'test_connection') {
    $payload = [
        'operacion' => 'generar_comprobante',
        'tipo_comprobante' => 'boleta',
        'serie' => 'B001',
        'numero' => 1,
        'fecha_emision' => date('d-m-Y'),
        'moneda' => 'PEN',
        'cliente_tipo_documento' => 'DNI',
        'cliente_numero_documento' => '00000000',
        'cliente_denominacion' => 'PRUEBA CONEXION',
        'totales' => true,
        'items' => [[
            'unidad' => 'NIU',
            'codigo' => 'TEST',
            'descripcion' => 'Producto de prueba',
            'cantidad' => 1,
            'valor_unitario' => 1.00,
            'precio_unitario' => 1.18,
            'subtotal' => 1.18,
            'tipo_afectacion_igv' => 'GRAVADO',
            'igv' => 0.18
        ]]
    ];
    
    $result = sendToPSE($apiUrl, $apiKey, $payload);
    logFacturacion('test_connection', $payload, $result);
    
    if ($result['code'] === 200) {
        $response = ['success' => true, 'message' => 'Conexión exitosa con PSE', 'data' => $result['body']];
    } else {
        $errorMsg = $result['error'] ?? ($result['body']['errors'] ?? 'Error desconocido');
        $response = ['success' => false, 'message' => 'Error: ' . (is_string($errorMsg) ? $errorMsg : json_encode($errorMsg))];
    }
}

// Emitir comprobante
elseif ($action === 'emitir_comprobante') {
    $tipoComprobante = $input['tipoComprobante'] ?? 'boleta';
    $serie = $input['serie'] ?? 'B001';
    $numero = $input['numero'] ?? 1;
    $clienteTipoDoc = $input['clienteTipoDocumento'] ?? 'DNI';
    $clienteNumDoc = $input['clienteNumeroDocumento'] ?? '';
    $clienteNombre = $input['clienteDenominacion'] ?? '';
    $clienteEmail = $input['clienteEmail'] ?? '';
    $items = $input['items'] ?? [];
    
    $payload = [
        'operacion' => 'generar_comprobante',
        'tipo_comprobante' => $tipoComprobante,
        'serie' => $serie,
        'numero' => $numero,
        'fecha_emision' => date('d-m-Y'),
        'moneda' => 'PEN',
        'cliente_tipo_documento' => $clienteTipoDoc,
        'cliente_numero_documento' => $clienteNumDoc,
        'cliente_denominacion' => $clienteNombre,
        'totales' => true,
        'enviar_email' => !empty($clienteEmail) ? true : false,
        'cliente_email' => $clienteEmail,
        'items' => []
    ];
    
    $totalIgv = 0;
    $totalBase = 0;
    
    foreach ($items as $item) {
        $base = $item['price'] * $item['qty'];
        $igv = $base * 0.18;
        $precioConIgv = ($item['price'] * 1.18);
        
        $totalBase += $base;
        $totalIgv += $igv;
        
        $payload['items'][] = [
            'unidad' => 'NIU',
            'codigo' => 'PROD' . ($item['menuId'] ?? uniqid()),
            'descripcion' => $item['name'] ?? 'Producto',
            'cantidad' => $item['qty'] ?? 1,
            'valor_unitario' => round($item['price'] ?? 0, 2),
            'precio_unitario' => round($precioConIgv, 2),
            'subtotal' => round($precioConIgv * ($item['qty'] ?? 1), 2),
            'tipo_afectacion_igv' => 'GRAVADO',
            'igv' => round($igv * ($item['qty'] ?? 1), 2)
        ];
    }
    
    $result = sendToPSE($apiUrl, $apiKey, $payload);
    logFacturacion('emitir_comprobante', $payload, $result);
    
    if ($result['code'] === 200) {
        $data = $result['body'];
        $response = [
            'success' => true,
            'tipo_comprobante' => $tipoComprobante,
            'serie_numero' => $serie . '-' . str_pad($numero, 8, '0', STR_PAD_LEFT),
            'link_pdf' => $data['enlaces']['pdf'] ?? ($data['link_pdf'] ?? ''),
            'link_xml' => $data['enlaces']['xml'] ?? ($data['link_xml'] ?? ''),
            'codigo_hash' => $data['codigo_hash'] ?? '',
            'data' => $data
        ];
    } else {
        $errorMsg = $result['error'] ?? ($result['body']['errors'] ?? 'Error al emitir comprobante');
        $response = [
            'success' => false,
            'message' => 'Error al emitir: ' . (is_string($errorMsg) ? $errorMsg : json_encode($errorMsg))
        ];
    }
}

// Anular comprobante
elseif ($action === 'anular_comprobante') {
    $tipoComprobante = $input['tipoComprobante'] ?? 'boleta';
    $serie = $input['serie'] ?? '';
    $numero = $input['numero'] ?? '';
    $motivo = $input['motivo'] ?? 'Anulación solicitada';
    
    $serieNC = $tipoComprobante === 'boleta' ? 'BC01' : 'FC01';
    
    $payload = [
        'operacion' => 'generar_comprobante',
        'tipo_comprobante' => 'nota_de_credito',
        'serie' => $serieNC,
        'numero' => $numero,
        'fecha_emision' => date('d-m-Y'),
        'moneda' => 'PEN',
        'comprobante_a_afectar' => $serie . '-' . str_pad($numero, 8, '0', STR_PAD_LEFT),
        'descripcion_sustento_descripcion' => $motivo,
        'totales' => true,
        'items' => [[
            'unidad' => 'NIU',
            'codigo' => 'DEV',
            'descripcion' => 'Anulación de comprobante',
            'cantidad' => 1,
            'valor_unitario' => 0.00,
            'precio_unitario' => 0.00,
            'subtotal' => 0.00,
            'tipo_afectacion_igv' => 'GRAVADO',
            'igv' => 0.00
        ]]
    ];
    
    $result = sendToPSE($apiUrl, $apiKey, $payload);
    logFacturacion('anular_comprobante', $payload, $result);
    
    if ($result['code'] === 200) {
        $response = ['success' => true, 'message' => 'Comprobante anulado', 'data' => $result['body']];
    } else {
        $errorMsg = $result['error'] ?? ($result['body']['errors'] ?? 'Error al anular');
        $response = ['success' => false, 'message' => 'Error al anular: ' . (is_string($errorMsg) ? $errorMsg : json_encode($errorMsg))];
    }
}

// Reenviar comprobante por email
elseif ($action === 'reenviar_comprobante') {
    $email = $input['email'] ?? '';
    $linkPdf = $input['linkPdf'] ?? '';
    
    if (empty($email)) {
        $response = ['success' => false, 'message' => 'Email requerido'];
    } else {
        // El PSE ya envió el email originalmente, aquí se puede reenviar
        $response = ['success' => true, 'message' => 'Comprobante reenviado a ' . $email];
    }
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>

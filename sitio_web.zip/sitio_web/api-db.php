<?php
/**
 * API de Sincronización de Base de Datos
 * Villa Moche ERP
 * 
 * Permite sincronizar la base de datos entre dispositivos
 * GET /api/db - Obtener DB
 * POST /api/db - Guardar DB
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dbFile = __DIR__ . '/db-shared.json';
$lockFile = __DIR__ . '/db-shared.lock';

// Función para adquirir bloqueo
function acquireLock($lockFile, $timeout = 5) {
    $start = time();
    while (file_exists($lockFile) && (time() - $start) < $timeout) {
        usleep(100000); // 100ms
    }
    return file_put_contents($lockFile, getmypid()) !== false;
}

// Función para liberar bloqueo
function releaseLock($lockFile) {
    @unlink($lockFile);
}

// GET - Obtener DB
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (file_exists($dbFile)) {
        $content = file_get_contents($dbFile);
        echo $content;
    } else {
        echo 'null';
    }
    exit;
}

// POST - Guardar DB
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if ($data === null && $input !== 'null') {
        http_response_code(400);
        echo json_encode(['error' => 'JSON inválido']);
        exit;
    }
    
    if (acquireLock($lockFile)) {
        try {
            file_put_contents($dbFile, $input);
            echo json_encode(['success' => true, 'timestamp' => date('c')]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Error al guardar: ' . $e->getMessage()]);
        }
        releaseLock($lockFile);
    } else {
        http_response_code(503);
        echo json_encode(['error' => 'Base de datos ocupada, intente nuevamente']);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Método no permitido']);
?>

# Villa Moche ERP - Guía de Despliegue en Hosting Compartido

## 📁 Estructura de Archivos

```
sitio_web/
├── index.html              (Redirige a menu/)
├── .htaccess               (Configuración principal)
├── api-db.php              (API de sincronización)
├── culqi-pos-proxy.php     (Endpoint POS Culqi)
├── facturacion-api.php     (Endpoint Facturación SUNAT)
├── logo01.png              (Logo del restaurante)
├── menu/
│   ├── index.html          (Carta digital pública)
│   └── logo01.png          (Logo para carta)
└── admin/
    ├── index.html          (Sistema ERP completo)
    ├── logo01.png          (Logo para admin)
    ├── .htaccess           (Protección de acceso)
    └── .htpasswd           (Credenciales)
```

## 🚀 Pasos para Subir al Hosting

### 1. Subir Archivos por FTP/cPanel

1. Conéctese a su hosting por FTP o use el Administrador de Archivos de cPanel
2. Navegue a la carpeta `public_html/` (o la carpeta raíz de su dominio)
3. Suba **TODO el contenido** de la carpeta `sitio_web/` (no la carpeta en sí, sino su contenido)

### 2. Configurar .htaccess del Admin

1. Abra el archivo `admin/.htaccess`
2. Busque la línea: `AuthUserFile /home/USUARIO/public_html/admin/.htpasswd`
3. Reemplace `USUARIO` con su usuario de cPanel
4. Ejemplo: `AuthUserFile /home/miusuario/public_html/admin/.htpasswd`

**Para encontrar la ruta absoluta en cPanel:**
- Vaya a cPanel → Administrador de Archivos
- Navegue hasta la carpeta `admin/`
- La ruta aparece en la barra superior

### 3. Cambiar Credenciales del Admin

El archivo `.htpasswd` viene con credenciales por defecto:
- **Usuario:** `admin`
- **Contraseña:** `villa2025`

**Para cambiarlas:**

**Opción A: Usar generador online**
1. Vaya a: https://www.htaccesstools.com/htpasswd-generator/
2. Ingrese usuario y nueva contraseña
3. Copie la línea generada
4. Reemplace el contenido de `.htpasswd`

**Opción B: Usar comando en servidor (si tiene acceso SSH)**
```bash
htpasswd -c /home/USUARIO/public_html/admin/.htpasswd nuevo_usuario
```

### 4. Configurar Permisos

En cPanel o FTP, asegúrese de que los permisos sean:
- Carpetas: `755`
- Archivos: `644`
- `db-shared.json`: `644` (se crea automáticamente al guardar)

### 5. Verificar Funcionamiento

**Carta Digital (pública):**
```
https://midominio.com/menu/
https://midominio.com/menu/?mesa=1
```

**Panel de Administración:**
```
https://midominio.com/admin/
```
Debe pedir usuario y contraseña del `.htpasswd`

**API de Sincronización:**
```
https://midominio.com/api/db
```

---

## 🔧 Configuración Adicional

### Activar HTTPS (Recomendado)

1. En cPanel, vaya a **SSL/TLS** o **Let's Encrypt**
2. Instale el certificado SSL para su dominio
3. Edite el `.htaccess` principal y descomente las líneas:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### Configurar Culqi POS

1. Edite el archivo `culqi-pos-proxy.php` si necesita cambiar la URL base
2. En el panel admin, configure sus llaves API de Culqi
3. Pruebe la conexión desde la sección POS

### Configurar Facturación Electrónica

1. Edite el archivo `facturacion-api.php` si usa un PSE diferente a Nubefact
2. En el panel admin, configure sus credenciales SUNAT/PSE
3. Pruebe la conexión desde la sección Facturación

---

## 📱 Generar Códigos QR

1. Abra en navegador: `https://midominio.com/qr-codes.html`
2. O suba el archivo `qr-codes.html` a la raíz del hosting
3. Imprima los QR y colóquelos en las mesas

**URL que deben tener los QR:**
```
https://midominio.com/menu/?mesa=1
https://midominio.com/menu/?mesa=2
...etc
```

---

## 🐛 Solución de Problemas

### "Error 500 - Internal Server Error"

**Causa:** Configuración incorrecta de `.htaccess`

**Solución:**
1. Verifique la ruta en `AuthUserFile` del `admin/.htaccess`
2. Verifique que el archivo `.htpasswd` exista
3. Verifique permisos (755 carpetas, 644 archivos)

### "Los pedidos no aparecen en cocina"

**Causa:** Problema de sincronización entre dispositivos

**Solución:**
1. Verifique que `api-db.php` tenga permisos de escritura
2. Verifique que `db-shared.json` se esté creando
3. Revise la consola del navegador (F12) para ver errores
4. Asegúrese de que todos los dispositivos estén en la misma red

### "No puedo acceder al admin"

**Causa:** Credenciales incorrectas o `.htpasswd` mal configurado

**Solución:**
1. Verifique el contenido de `.htpasswd`
2. Regenere las credenciales con el generador online
3. Verifique la ruta en `AuthUserFile`

### "La carta digital no carga el menú"

**Causa:** Base de datos no inicializada

**Solución:**
1. Primero abra el admin: `https://midominio.com/admin/`
2. Inicie sesión y espere a que cargue todo
3. Esto inicializa la base de datos
4. Ahora la carta digital debería funcionar

---

## 🔐 Seguridad

### Recomendaciones:

1. **Cambie las credenciales por defecto** del `.htpasswd`
2. **Active HTTPS** para todas las conexiones
3. **No exponga** el archivo `db-shared.json` (ya está protegido)
4. **Haga backups regulares** de `db-shared.json`
5. **Restrinja el acceso** a la carpeta admin solo por IP si es posible

### Backup de Base de Datos:

Para hacer backup, descargue el archivo `db-shared.json` desde FTP/cPanel.

Para restaurar, suba el archivo de backup reemplazando el actual.

---

## 📞 Soporte

Si tiene problemas:

1. Revise la consola del navegador (F12) en busca de errores
2. Verifique los logs de error en cPanel
3. Compruebe que todos los archivos se subieron correctamente
4. Verifique permisos de archivos y carpetas

---

**Villa Moche ERP v3.0**  
*Sistema de Gestión para Restaurantes*

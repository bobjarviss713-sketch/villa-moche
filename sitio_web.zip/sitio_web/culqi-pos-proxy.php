<?php
/**
 * Culqi POS Proxy - Endpoint para integración con Culqi POS
 * Villa Moche ERP
 * 
 * Coloque este archivo en la raíz del hosting (misma carpeta que menu/ y admin/)
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';
$secretKey = $input['secretKey'] ?? '';
$environment = $input['environment'] ?? 'integracion';

$baseUrl = 'https://api.culqi.com/v2';

function culqiRequest($endpoint, $method, $secretKey, $data = null) {
    global $baseUrl;
    $ch = curl_init($baseUrl . $endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $secretKey,
        'Content-Type: application/json'
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['code' => 0, 'body' => ['merchant_message' => 'Error de conexión: ' . $error]];
    }
    return ['code' => $httpCode, 'body' => json_decode($response, true)];
}

$response = ['success' => false, 'message' => 'Acción no válida'];

// Probar conexión
if ($action === 'test_connection') {
    $result = culqiRequest('/charges', 'GET', $secretKey);
    if ($result['code'] === 200) {
        $response = ['success' => true, 'message' => 'Conexión exitosa con Culqi'];
    } else {
        $response = ['success' => false, 'message' => $result['body']['merchant_message'] ?? 'Credenciales inválidas'];
    }
}

// Crear cargo
elseif ($action === 'create_charge') {
    $amount = intval(($input['amount'] ?? 0) * 100);
    $data = [
        'amount' => $amount,
        'currency_code' => 'PEN',
        'email' => $input['email'] ?? 'pos@villamoche.com',
        'metadata' => $input['metadata'] ?? []
    ];
    if (!empty($input['source_id'])) {
        $data['source_id'] = $input['source_id'];
    }
    
    $result = culqiRequest('/charges', 'POST', $secretKey, $data);
    if ($result['code'] === 200 || $result['code'] === 201) {
        $response = [
            'success' => true,
            'charge_id' => $result['body']['id'] ?? '',
            'state' => $result['body']['state'] ?? 'pending',
            'data' => $result['body']
        ];
    } else {
        $response = [
            'success' => false,
            'message' => $result['body']['merchant_message'] ?? 'Error al crear cargo'
        ];
    }
}

// Verificar estado de cargo
elseif ($action === 'check_charge') {
    $chargeId = $input['charge_id'] ?? '';
    if (empty($chargeId)) {
        $response = ['success' => false, 'message' => 'charge_id requerido'];
    } else {
        $result = culqiRequest('/charges/' . $chargeId, 'GET', $secretKey);
        if ($result['code'] === 200) {
            $response = [
                'success' => true,
                'state' => $result['body']['state'] ?? 'unknown',
                'data' => $result['body']
            ];
        } else {
            $response = ['success' => false, 'message' => 'Cargo no encontrado'];
        }
    }
}

// Reembolsar cargo
elseif ($action === 'refund_charge') {
    $chargeId = $input['charge_id'] ?? '';
    $amount = intval(($input['amount'] ?? 0) * 100);
    
    $result = culqiRequest('/refunds', 'POST', $secretKey, [
        'amount' => $amount,
        'charge_id' => $chargeId,
        'reason' => $input['reason'] ?? 'Solicitud de reembolso'
    ]);
    
    if ($result['code'] === 200 || $result['code'] === 201) {
        $response = [
            'success' => true,
            'refund_id' => $result['body']['id'] ?? '',
            'data' => $result['body']
        ];
    } else {
        $response = [
            'success' => false,
            'message' => $result['body']['merchant_message'] ?? 'Error al reembolsar'
        ];
    }
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>

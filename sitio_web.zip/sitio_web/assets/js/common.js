/**
 * ============================================
 * VILLA MOCHE - FUNCIONES COMPARTIDAS
 * common.js - Header dinámico, menú móvil, utilidades
 * ============================================
 */

(function() {
    'use strict';

    // ============================================
    // CONFIGURACIÓN
    // ============================================
    var VM_CONFIG = {
        siteName: 'VILLA MOCHE',
        siteSlogan: 'Recreo Campestre',
        logo: 'logo01.png',
        paths: {
            home: 'index.html',
            menu: 'menu/',
            admin: 'admin/'
        }
    };

    // ============================================
    // HEADER DINÁMICO
    // ============================================
    function createHeader(currentPage) {
        var header = document.createElement('header');
        header.className = 'vm-header';
        header.innerHTML = '\
            <div class="vm-header-container">\
                <a href="' + VM_CONFIG.paths.home + '" class="vm-logo-section" style="text-decoration:none;color:inherit;">\
                    <div class="vm-logo">\
                        <img src="' + VM_CONFIG.logo + '" alt="' + VM_CONFIG.siteName + '" onerror="this.src=\'https://placehold.co/60x60/7A4A20/FFFFFF?text=VM\'">\
                    </div>\
                    <div class="vm-brand">\
                        <h1>' + VM_CONFIG.siteName + '</h1>\
                        <p>' + VM_CONFIG.siteSlogan + '</p>\
                    </div>\
                </a>\
                <button class="vm-menu-toggle" onclick="toggleMobileMenu()" aria-label="Menú">\
                    <i class="fas fa-bars"></i>\
                </button>\
                <nav class="vm-nav" id="vmNav">\
                    <a href="' + VM_CONFIG.paths.home + '" class="vm-nav-link' + (currentPage === 'home' ? ' active' : '') + '">\
                        <i class="fas fa-home"></i> Inicio\
                    </a>\
                    <a href="' + VM_CONFIG.paths.menu + '" class="vm-nav-link' + (currentPage === 'menu' ? ' active' : '') + '">\
                        <i class="fas fa-utensils"></i> Carta Digital\
                    </a>\
                    <a href="' + VM_CONFIG.paths.admin + '" class="vm-nav-link admin-link' + (currentPage === 'admin' ? ' active' : '') + '" title="Acceso Personal">\
                        <i class="fas fa-lock"></i> Sistema\
                    </a>\
                </nav>\
            </div>\
        ';
        
        // Insertar al inicio del body
        if (document.body.firstChild) {
            document.body.insertBefore(header, document.body.firstChild);
        } else {
            document.body.appendChild(header);
        }
    }

    // ============================================
    // FOOTER DINÁMICO
    // ============================================
    function createFooter() {
        var currentYear = new Date().getFullYear();
        
        var footer = document.createElement('footer');
        footer.className = 'vm-footer';
        footer.innerHTML = '\
            <div class="vm-footer-container">\
                <div class="vm-footer-grid">\
                    <div class="vm-footer-section">\
                        <h3><i class="fas fa-utensils"></i> Villa Moche</h3>\
                        <p>Recreo campestre con la mejor gastronomía tradicional peruana. Sabores que trascienden generaciones en un ambiente único.</p>\
                        <div class="vm-social-links">\
                            <a href="#" class="vm-social-link" title="Facebook"><i class="fab fa-facebook-f"></i></a>\
                            <a href="#" class="vm-social-link" title="Instagram"><i class="fab fa-instagram"></i></a>\
                            <a href="#" class="vm-social-link" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>\
                            <a href="#" class="vm-social-link" title="TikTok"><i class="fab fa-tiktok"></i></a>\
                        </div>\
                    </div>\
                    <div class="vm-footer-section">\
                        <h3><i class="fas fa-clock"></i> Horarios</h3>\
                        <ul>\
                            <li><i class="fas fa-calendar-day"></i> Lunes a Viernes: 11:00 AM - 10:00 PM</li>\
                            <li><i class="fas fa-calendar-week"></i> Sábados: 10:00 AM - 11:00 PM</li>\
                            <li><i class="fas fa-calendar-alt"></i> Domingos: 10:00 AM - 9:00 PM</li>\
                            <li><i class="fas fa-star"></i> Feriados: 10:00 AM - 10:00 PM</li>\
                        </ul>\
                    </div>\
                    <div class="vm-footer-section">\
                        <h3><i class="fas fa-map-marker-alt"></i> Contacto</h3>\
                        <ul>\
                            <li><i class="fas fa-location-dot"></i> Km 15, Carretera a Moche, Trujillo</li>\
                            <li><i class="fas fa-phone"></i> <a href="tel:+51944123456">(044) 123-456</a></li>\
                            <li><i class="fab fa-whatsapp"></i> <a href="https://wa.me/51944123456">+51 944 123 456</a></li>\
                            <li><i class="fas fa-envelope"></i> <a href="mailto:info@villamoche.com">info@villamoche.com</a></li>\
                        </ul>\
                    </div>\
                    <div class="vm-footer-section">\
                        <h3><i class="fas fa-link"></i> Enlaces</h3>\
                        <ul>\
                            <li><i class="fas fa-home"></i> <a href="' + VM_CONFIG.paths.home + '">Inicio</a></li>\
                            <li><i class="fas fa-utensils"></i> <a href="' + VM_CONFIG.paths.menu + '">Carta Digital</a></li>\
                            <li><i class="fas fa-qrcode"></i> <a href="' + VM_CONFIG.paths.menu + '?mesa=1">Pedir por QR</a></li>\
                            <li><i class="fas fa-lock"></i> <a href="' + VM_CONFIG.paths.admin + '">Acceso Personal</a></li>\
                        </ul>\
                    </div>\
                </div>\
                <div class="vm-footer-bottom">\
                    <p>&copy; ' + currentYear + ' Villa Moche - Recreo Campestre. Todos los derechos reservados.</p>\
                    <p>Hecho con <span class="vm-footer-heart"><i class="fas fa-heart"></i></span> en Trujillo, Perú</p>\
                </div>\
            </div>\
        ';
        
        document.body.appendChild(footer);
    }

    // ============================================
    // MENÚ MÓVIL
    // ============================================
    window.toggleMobileMenu = function() {
        var nav = document.getElementById('vmNav');
        if (nav) {
            nav.classList.toggle('active');
        }
    };

    // Cerrar menú al hacer clic en un enlace (móvil)
    function setupMobileMenuClose() {
        document.addEventListener('click', function(e) {
            if (e.target.closest('.vm-nav-link')) {
                var nav = document.getElementById('vmNav');
                if (nav && nav.classList.contains('active')) {
                    nav.classList.remove('active');
                }
            }
        });
    }

    // ============================================
    // HEADER STICKY CON SOMBRA
    // ============================================
    function setupStickyHeader() {
        var header = document.querySelector('.vm-header');
        if (!header) return;
        
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.style.boxShadow = '0 4px 30px rgba(0, 0, 0, 0.3)';
                header.style.padding = '0.5rem 2rem';
            } else {
                header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.2)';
                header.style.padding = '1rem 2rem';
            }
        });
    }

    // ============================================
    // INICIALIZACIÓN
    // ============================================
    function init() {
        // Detectar página actual
        var path = window.location.pathname;
        var currentPage = 'home';
        
        if (path.indexOf('menu') !== -1) {
            currentPage = 'menu';
        } else if (path.indexOf('admin') !== -1) {
            currentPage = 'admin';
        }
        
        // No crear header/footer si estamos en el admin (tiene su propio sistema)
        if (currentPage !== 'admin') {
            createHeader(currentPage);
            createFooter();
            setupStickyHeader();
            setupMobileMenuClose();
        }
        
        console.log('%c🍽️ Villa Moche - Sitio Web Cargado', 'color: #6DAE4A; font-weight: bold; font-size: 14px;');
        console.log('%cPágina actual: ' + currentPage, 'color: #7A4A20;');
    }

    // Ejecutar cuando el DOM esté listo
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // ============================================
    // UTILIDADES EXPORTADAS
    // ============================================
    window.VillaMoche = {
        config: VM_CONFIG,
        createHeader: createHeader,
        createFooter: createFooter
    };

})();

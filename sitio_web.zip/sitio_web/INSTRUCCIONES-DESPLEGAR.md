# 🚀 Guía Rápida de Despliegue - Villa Moche ERP

## ✅ Estructura Lista para Subir

La carpeta `sitio_web/` contiene TODO lo necesario para subir a tu hosting:

```
sitio_web/
├── index.html              ← Redirige a menu/
├── .htaccess               ← Configuración principal
├── api-db.php              ← API de sincronización
├── culqi-pos-proxy.php     ← POS Culqi
├── facturacion-api.php     ← Facturación SUNAT
├── logo01.png              ← Logo
├── README-DEPLOY.md        ← Guía completa
├── menu/
│   ├── index.html          ← Carta digital pública
│   └── logo01.png
└── admin/
    ├── index.html          ← Sistema ERP completo
    ├── logo01.png
    ├── .htaccess           ← Protección de acceso
    └── .htpasswd           ← Credenciales (admin/villa2025)
```

## 📤 Pasos para Subir al Hosting

### 1. Subir Archivos
- Abre el **Administrador de Archivos** de cPanel o conecta por **FTP**
- Ve a la carpeta `public_html/` (o la raíz de tu dominio)
- Sube **TODO el contenido** de la carpeta `sitio_web/`

### 2. Configurar Protección del Admin
1. Abre el archivo `admin/.htaccess`
2. Busca la línea: `AuthUserFile /home/USUARIO/public_html/admin/.htpasswd`
3. Reemplaza `USUARIO` con tu usuario de cPanel
4. Ejemplo: `AuthUserFile /home/miusuario/public_html/admin/.htpasswd`

**Para encontrar tu ruta absoluta:**
- En cPanel → Administrador de Archivos → navega a `admin/`
- La ruta aparece en la barra superior

### 3. Cambiar Contraseña (IMPORTANTE)
Las credenciales por defecto son:
- **Usuario:** `admin`
- **Contraseña:** `villa2025`

**Para cambiarlas:**
1. Ve a: https://www.htaccesstools.com/htpasswd-generator/
2. Genera el hash con tu nuevo usuario y contraseña
3. Reemplaza el contenido de `admin/.htpasswd`

### 4. Verificar Permisos
En cPanel o FTP, asegúrate que:
- Carpetas: **755**
- Archivos: **644**
- `db-shared.json`: Se crea automáticamente (644)

## 🌐 URLs de Acceso

### Carta Digital (Pública)
```
https://midominio.com/menu/
https://midominio.com/menu/?mesa=1
https://midominio.com/menu/?mesa=2
```

### Panel de Administración
```
https://midominio.com/admin/
```
Pedirá usuario y contraseña del `.htpasswd`

### API de Sincronización
```
https://midominio.com/api-db.php
```

## 📱 Generar Códigos QR

1. Abre: `https://midominio.com/qr-codes.html`
   (Sube el archivo `qr-codes.html` desde tu carpeta original)
2. Los QR apuntan automáticamente a: `https://midominio.com/menu/?mesa=X`
3. Imprime y coloca en cada mesa

## 🔧 Configuraciones Adicionales

### Activar HTTPS
1. En cPanel → SSL/TLS o Let's Encrypt
2. Instala el certificado para tu dominio
3. Edita `.htaccess` principal y descomenta:
```apache
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### Configurar Culqi POS
1. Inicia sesión en el admin
2. Ve a la sección **POS**
3. Ingresa tus llaves API de Culqi
4. Prueba la conexión

### Configurar Facturación Electrónica
1. Inicia sesión en el admin
2. Ve a la sección **Facturación**
3. Configura tu PSE (Nubefact, Factura.pe, etc.)
4. Ingresa RUC, credenciales SUNAT, etc.

## 🐛 Solución de Problemas

### Error 500
- Verifica la ruta en `AuthUserFile` del `admin/.htaccess`
- Verifica que `.htpasswd` exista
- Revisa permisos (755 carpetas, 644 archivos)

### Pedidos no aparecen en cocina
- Verifica que `api-db.php` tenga permisos de escritura
- Verifica que `db-shared.json` se esté creando
- Recarga la página de cocina (F5)

### No puedo acceder al admin
- Verifica credenciales en `.htpasswd`
- Verifica la ruta absoluta en `AuthUserFile`
- Regenera el `.htpasswd` si es necesario

### Carta digital no carga menú
- Primero abre el admin: `https://midominio.com/admin/`
- Inicia sesión para inicializar la base de datos
- Luego la carta digital funcionará

## 🔐 Seguridad

✅ **Cambia las credenciales por defecto** del `.htpasswd`
✅ **Activa HTTPS** para todas las conexiones
✅ **No expongas** `db-shared.json` (ya está protegido)
✅ **Haz backups** regulares de `db-shared.json`

## 📞 Soporte

Si tienes problemas:
1. Revisa la consola del navegador (F12)
2. Verifica los logs de error en cPanel
3. Comprueba que todos los archivos se subieron
4. Verifica permisos de archivos y carpetas

---

**Villa Moche ERP v3.0**  
*Sistema de Gestión para Restaurantes*
